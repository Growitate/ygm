import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { ArrowUpRight, Menu, Phone, X } from 'lucide-react';

const navItems = [
  { label: 'Home', to: '/' },
  { label: 'Products', to: '/products' },
  { label: 'About', to: '/about' },
  { label: 'Contact', to: '/contact' },
];

export function BrandMark({ light = false }) {
  return (
    <Link className={`brand-lockup${light ? ' brand-lockup-light' : ''}`} to="/" aria-label="YGM Global home">
      <svg className="brand-symbol" viewBox="0 0 42 42" role="img" aria-label="YGM strata mark">
        <path d="M5 31.5 13 20l8 11.5 8-11.5 8 11.5H5Z" />
        <path d="M9 16.5 16.5 6 24 16.5 31.5 6l7.5 10.5H9Z" />
        <path d="M13 36h26" />
      </svg>
      <span className="brand-wordmark"><strong>YGM</strong><small>GLOBAL</small></span>
    </Link>
  );
}

export function SiteHeader() {
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <header className="site-header">
      <div className="container header-inner">
        <BrandMark />
        <button className="menu-toggle" type="button" aria-label={menuOpen ? 'Close navigation' : 'Open navigation'} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X size={21} /> : <Menu size={21} />}
        </button>
        <nav className={`main-nav${menuOpen ? ' is-open' : ''}`} aria-label="Main navigation">
          {navItems.map((item) => <NavLink key={item.to} to={item.to} end={item.to === '/'} className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'} onClick={() => setMenuOpen(false)}>{item.label}</NavLink>)}
        </nav>
        <div className="header-actions"><a className="header-phone" href="tel:+918660375708"><Phone size={14} /><span>+91 86603 75708</span></a><Link className="nav-cta" to="/contact#enquiry" onClick={() => setMenuOpen(false)}>Enquire now <ArrowUpRight size={14} /></Link></div>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="container footer-main">
        <div className="footer-brand-col"><BrandMark /><p>From Indian Quarries<br />to Global Markets</p><span className="footer-note">INDIA · NATURAL STONE SOURCING</span></div>
        <div className="footer-col"><span className="footer-label">Explore</span><Link to="/products">Stone categories</Link><Link to="/about">About YGM Global</Link><Link to="/contact">Make an enquiry</Link><Link to="/privacy">Privacy</Link></div>
        <div className="footer-col"><span className="footer-label">Email</span><a href="mailto:yashwanth@ygmglobal.in">yashwanth@ygmglobal.in</a><a href="mailto:contact@ygmglobal.in">contact@ygmglobal.in</a><a href="https://www.instagram.com/ygmglobal01?dlrf=MTAybzBtN2hsNzg4aA==" target="_blank" rel="noreferrer">Instagram <ArrowUpRight size={13} /></a></div>
        <div className="footer-col"><span className="footer-label">Call / WhatsApp</span><a href="tel:+918660375708">+91 86603 75708</a><a href="tel:+918792720101">+91 87927 20101</a><a href="https://wa.me/918660375708" target="_blank" rel="noreferrer">Message us on WhatsApp <ArrowUpRight size={13} /></a></div>
      </div>
      <div className="container footer-bottom"><span>© {new Date().getFullYear()} YGM Global Private Limited</span><span>Natural stone connections, from India to the world.</span><Link to="/privacy">Privacy &amp; enquiries</Link></div>
    </footer>
  );
}
