import { useState } from 'react';
import { ArrowUpRight, Check, Mail, MapPin, MessageCircle, Phone } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';

const emailAddress = 'contact@ygmglobal.in';

export default function ContactPage() {
  const [searchParams] = useSearchParams();
  const [submitted, setSubmitted] = useState(false);
  const [formError, setFormError] = useState('');

  function handleSubmit(event) {
    event.preventDefault();
    setFormError('');
    const form = new FormData(event.currentTarget);
    const name = form.get('name').trim();
    const email = form.get('email').trim();
    const stone = form.get('stone');
    const message = form.get('message').trim();
    if (!name || !email || !message) {
      setFormError('Please complete the required fields before continuing.');
      return;
    }
    const subject = encodeURIComponent(`Natural stone enquiry${stone ? ` — ${stone}` : ''}`);
    const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\nCompany: ${form.get('company') || 'Not provided'}\nStone of interest: ${stone || 'Not selected'}\n\nRequirements:\n${message}`);
    setSubmitted(true);
    window.location.href = `mailto:${emailAddress}?subject=${subject}&body=${body}`;
  }

  return (
    <>
      <section className="contact-hero"><div className="container contact-hero-inner"><div><p className="eyebrow"><span /> 04 — YOUR ENQUIRY STARTS HERE</p><h1>Good sourcing<br />begins with <em>a conversation.</em></h1></div><p>Tell us what you are looking for. We’ll take the time to understand your requirements and explore the right place to begin.</p></div></section>
      <section className="contact-section" id="enquiry"><div className="container contact-grid">
        <div className="contact-form-wrap"><p className="eyebrow">SHARE YOUR REQUIREMENTS</p><h2>What can we<br /><em>help you source?</em></h2><p className="form-intro">A few details will help us understand your enquiry. Pricing is shared on request.</p>
          <form className="enquiry-form" onSubmit={handleSubmit}>
            <div className="form-row"><label>Your name <span>*</span><input name="name" type="text" autoComplete="name" placeholder="Name" required /></label><label>Business email <span>*</span><input name="email" type="email" autoComplete="email" placeholder="you@company.com" required /></label></div>
            <div className="form-row"><label>Company <span className="optional">OPTIONAL</span><input name="company" type="text" autoComplete="organization" placeholder="Company name" /></label><label>Stone of interest <span className="optional">OPTIONAL</span><select name="stone" defaultValue={searchParams.get('stone') || ''}><option value="">Select a material</option><option>Granite</option><option>Marble</option><option>Limestone</option><option>Sandstone</option><option>Slate</option><option>Multiple / not sure</option></select></label></div>
            <label>Tell us about your requirements <span>*</span><textarea name="message" rows="4" placeholder="Stone type, colour, finish, application or any other details that matter to you…" required /></label>
            <div className="form-action"><button className="button button-dark" type="submit">Prepare your enquiry <ArrowUpRight size={16} /></button><span>Opens a new email in your email app.</span></div>
            {formError && <p className="form-error" role="alert">{formError}</p>}
            {submitted && <p className="form-success" role="status"><Check size={15} /> Your email app should open with your enquiry. If it does not, write to <a href={`mailto:${emailAddress}`}>{emailAddress}</a>.</p>}
            <p className="form-privacy">Your message is not sent or stored on this website. Submitting prepares a draft email in your device’s email application.</p>
          </form>
        </div>

        <aside className="contact-aside"><div className="contact-aside-photo"><img src="/manus-storage/async-images/d4YLJMXoIC5WEIii66Zprh/image-4.webp" alt="Natural stone material with a finely textured surface" loading="lazy" /><span>MAKE THE FIRST CONNECTION</span></div><div className="contact-details"><p className="eyebrow">DIRECT CONTACT</p><a className="contact-detail" href={`mailto:${emailAddress}`}><span><Mail size={17} /></span><div><small>EMAIL</small><strong>{emailAddress}</strong></div><ArrowUpRight size={15} /></a><a className="contact-detail" href="mailto:yashwanth@ygmglobal.in"><span><Mail size={17} /></span><div><small>DIRECT EMAIL</small><strong>yashwanth@ygmglobal.in</strong></div><ArrowUpRight size={15} /></a><a className="contact-detail" href="tel:+918660375708"><span><Phone size={17} /></span><div><small>PHONE / WHATSAPP</small><strong>+91 86603 75708</strong></div><ArrowUpRight size={15} /></a><a className="contact-detail" href="tel:+918792720101"><span><Phone size={17} /></span><div><small>PHONE</small><strong>+91 87927 20101</strong></div><ArrowUpRight size={15} /></a><a className="contact-detail contact-detail-whatsapp" href="https://wa.me/918660375708" target="_blank" rel="noreferrer"><span><MessageCircle size={17} /></span><div><small>WHATSAPP</small><strong>Start a WhatsApp chat</strong></div><ArrowUpRight size={15} /></a><a className="contact-detail" href="https://www.instagram.com/ygmglobal01?dlrf=MTAybzBtN2hsNzg4aA==" target="_blank" rel="noreferrer"><span><MapPin size={17} /></span><div><small>FOLLOW ALONG</small><strong>Instagram · @ygmglobal01</strong></div><ArrowUpRight size={15} /></a></div></aside>
      </div></section>
    </>
  );
}
