import { ArrowRight, ArrowUpRight, BadgeCheck, Boxes, Compass, MessageCircle, MoveUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { products } from '../data/products.js';

const benefits = [
  { icon: <Compass size={20} strokeWidth={1.6} />, label: 'A clear starting point', title: 'Sourcing, centred on you', body: 'We begin with your intended use, the stone you have in mind and the details that matter to your business.' },
  { icon: <Boxes size={20} strokeWidth={1.6} />, label: 'Across stone families', title: 'India’s many materials', body: 'Explore granite, marble, limestone, sandstone and slate through one dedicated business contact.' },
  { icon: <MessageCircle size={20} strokeWidth={1.6} />, label: 'Straightforward dialogue', title: 'Clear communication', body: 'Discuss product possibilities, source options and next steps in a focused, buyer-led conversation.' },
];

export default function HomePage() {
  return (
    <>
      <section className="hero hero-home">
        <div className="hero-content container">
          <p className="eyebrow"><span /> YGM GLOBAL · FROM INDIAN QUARRIES TO GLOBAL MARKETS</p>
          <h1>Bringing the Beauty of<br />Indian Natural Stones<br className="hero-break" /> to the World</h1>
          <p className="hero-copy">Connecting international buyers with India’s natural-stone sourcing network—thoughtfully, clearly and around your requirements.</p>
          <div className="hero-actions"><Link className="button button-sand" to="/contact#enquiry">Request sourcing information <ArrowUpRight size={16} /></Link><Link className="text-link" to="/products">Explore stone categories <ArrowRight size={15} /></Link></div>
        </div>
        <div className="hero-stone-fan" aria-label="An arrangement of Indian natural stone samples">
          {products.map((product, index) => <div className={`fan-slab fan-slab-${index + 1} ${product.imageClass}`} key={product.id}><img src={product.image} alt={`${product.name} natural stone sample`} /></div>)}
        </div>
        <div className="container hero-proof-strip">
          <article className="proof-card"><span className="proof-icon"><BadgeCheck size={19} /></span><div><small>HOW WE WORK</small><strong>Buyer-focused sourcing</strong><p>Options shaped around your brief</p></div><span className="proof-mark">01</span></article>
          <article className="proof-card"><span className="proof-icon"><Boxes size={19} /></span><div><small>WHAT WE SOURCE</small><strong>Five natural stone families</strong><p>One point of business contact</p></div><span className="proof-mark">02</span></article>
          <article className="proof-card"><span className="proof-icon"><MessageCircle size={19} /></span><div><small>HOW WE CONNECT</small><strong>Clear product conversations</strong><p>Direct enquiry. Thoughtful follow-through.</p></div><span className="proof-mark">03</span></article>
        </div>
      </section>

      <section className="benefits-section section-pad">
        <div className="container">
          <div className="section-heading centered-heading"><p className="eyebrow">A MORE CONSIDERED WAY TO SOURCE</p><h2>India’s stone network.<br /><span>One clear conversation.</span></h2><p>YGM Global helps international buyers navigate product options and connect with relevant Indian suppliers.</p></div>
          <div className="benefit-grid">{benefits.map((benefit, index) => <article className="benefit-card" key={benefit.title}><div className="benefit-top"><span className="benefit-icon">{benefit.icon}</span><small>0{index + 1} · {benefit.label}</small></div><h3>{benefit.title}</h3><p>{benefit.body}</p></article>)}</div>
        </div>
      </section>

      <section className="home-catalogue section-pad">
        <div className="container">
          <div className="catalogue-heading"><div><p className="eyebrow">THE NATURAL STONE COLLECTION</p><h2>Find the material<br />for your next <span>project.</span></h2></div><div className="catalogue-heading-side"><p>Five distinct stone categories.<br />Sourcing enquiries tailored to you.</p><Link className="text-link" to="/products">View all stone categories <ArrowRight size={15} /></Link></div></div>
          <div className="home-product-grid">{products.map((product, index) => <article className="home-stone-card" key={product.id}><Link className={`home-stone-photo ${product.imageClass}`} to={`/products#${product.id}`} aria-label={`Explore ${product.name}`}><img src={product.image} alt={product.alt} loading="lazy" /><span className="stone-card-count">0{index + 1}</span><span className="stone-card-arrow"><ArrowUpRight size={16} /></span></Link><div className="home-stone-info"><div><small>{product.descriptor}</small><h3>{product.name}</h3></div><Link to={`/contact?stone=${encodeURIComponent(product.name)}#enquiry`} aria-label={`Enquire about ${product.name}`}><ArrowUpRight size={16} /></Link></div><p className="home-stone-note">Pricing and sourcing details on request.</p></article>)}</div>
          <div className="catalogue-disclaimer"><span className="disclaimer-dot" /> Stone appearance and availability vary by source, finish and specification. Ask us about options for your requirements.</div>
        </div>
      </section>

      <section className="source-feature"><div className="source-feature-photo"><img src="/manus-storage/async-images/d4YLJMXoIC5WEIii66Zprh/image-1.webp" alt="Close view of a natural stone slab with rich mineral character" loading="lazy" /><span>STONE HAS A PLACE OF ORIGIN. SOURCING BUILDS A BRIDGE.</span></div><div className="source-feature-copy"><p className="eyebrow">FROM INDIA TO GLOBAL MARKETS</p><h2>A sourcing partner,<br />not just a <span>stone list.</span></h2><p>YGM Global was established to make Indian natural stone sourcing more accessible for international buyers. We listen to your requirements, help explore relevant supplier connections and keep the conversation clear at every step.</p><Link className="button button-outline" to="/about">Learn about YGM Global <ArrowRight size={15} /></Link></div></section>

      <section className="orange-cta"><div className="container orange-cta-inner"><div><p className="eyebrow eyebrow-light">YOUR REQUIREMENTS COME FIRST</p><h2>Looking for a natural<br />stone sourcing partner?</h2><p>Tell us what you need. We’ll help you find the right place to start.</p></div><Link className="button button-white" to="/contact#enquiry">Start an enquiry <ArrowUpRight size={16} /></Link><div className="cta-stone-stamp" aria-hidden="true"><img src="/manus-storage/async-images/d4YLJMXoIC5WEIii66Zprh/image-3.webp" alt="" /></div></div></section>
    </>
  );
}
