import { ArrowRight, ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { products } from '../data/products.js';

export default function ProductsPage() {
  return (
    <>
      <section className="catalogue-page-hero">
        <div className="container catalogue-page-hero-inner"><p className="eyebrow"><span /> NATURAL STONE · INDIA</p><h1>Materials with<br /><span>a sense of origin.</span></h1><p>Discover India’s natural-stone possibilities for your project or business. Share your preferred stone, finish or specification to begin a sourcing enquiry.</p><Link className="button button-sand" to="/contact#enquiry">Ask about availability <ArrowUpRight size={16} /></Link><div className="catalogue-tabs" aria-label="Stone category shortcuts">{products.map((product, index) => <a href={`#${product.id}`} key={product.id}><span>0{index + 1}</span>{product.name}</a>)}</div></div>
        <div className="catalogue-hero-swatches" aria-hidden="true"><div className="catalogue-swatch swatch-one"><img src="/manus-storage/async-images/d4YLJMXoIC5WEIii66Zprh/image-2.webp" alt="" /></div><div className="catalogue-swatch swatch-two"><img src="/manus-storage/async-images/d4YLJMXoIC5WEIii66Zprh/image-3.webp" alt="" /></div><div className="catalogue-swatch swatch-three"><img src="/manus-storage/async-images/d4YLJMXoIC5WEIii66Zprh/image-5.webp" alt="" /></div></div>
      </section>

      <section className="catalogue-grid-section section-pad"><div className="container"><div className="section-heading catalogue-page-heading"><p className="eyebrow">EXPLORE THE COLLECTION</p><h2>Indian natural stone,<br /><span>by category.</span></h2><p>Availability and product details depend on the source. Pricing is shared on enquiry.</p></div>
        <div className="catalogue-cards">{products.map((product, index) => <article className="catalogue-card" id={product.id} key={product.id}><Link className={`catalogue-card-image ${product.imageClass}`} to={`/contact?stone=${encodeURIComponent(product.name)}#enquiry`} aria-label={`Enquire about ${product.name}`}><img src={product.image} alt={product.alt} loading="lazy" /><span className="catalogue-card-number">0{index + 1} / 05</span><span className="catalogue-card-image-arrow"><ArrowUpRight size={17} /></span></Link><div className="catalogue-card-copy"><small>{product.descriptor}</small><h3>{product.name}</h3><p>{product.description}</p><div className="catalogue-card-bottom"><span>PRICING ON REQUEST</span><Link to={`/contact?stone=${encodeURIComponent(product.name)}#enquiry`}>Request information <ArrowRight size={14} /></Link></div></div></article>)}</div>
      </div></section>

      <section className="catalogue-inquiry-band"><div className="container inquiry-band-inner"><div><p className="eyebrow eyebrow-light">A PROJECT IN MIND?</p><h2>Let’s discuss the<br />right <span>material.</span></h2><p>Share a product, finish or sourcing requirement. We’ll help clarify the next step.</p></div><Link className="button button-white" to="/contact#enquiry">Enquire with YGM Global <ArrowUpRight size={16} /></Link><div className="inquiry-band-texture" aria-hidden="true">YGM</div></div></section>
    </>
  );
}
